# 13 - Checklist final do prompt

- [x] Objetivo do pacote atendido.
- [x] Arquitetura Flow-first avaliada.
- [x] Flows existentes analisados.
- [x] Services existentes analisados.
- [x] Decisao entre Flow, Flow + Apex Invocable, Service existente ou Trigger documentada.
- [x] Fora do escopo respeitado.
- [x] Nenhum campo removido no 16B foi usado/recriado.
- [x] Nenhum valor antigo de `EscopoRegra__c` foi usado.
- [x] Regra implementada somente para Area Interna Custom.
- [x] Registros Standard nao sao pausados/retomados.
- [x] Campos novos nao foram criados.
- [x] Testes obrigatorios foram executados.
- [x] `package.xml` minimo e sem wildcard.
- [x] UTF-8 sem BOM.
- [x] Sem mojibake.
- [x] Nenhum artefato extra foi incluido no delta.
- [x] O prompt foi relido antes da finalizacao.
