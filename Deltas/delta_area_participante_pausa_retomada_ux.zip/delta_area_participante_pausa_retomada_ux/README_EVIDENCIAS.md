# Pacote 23 - UX de pausa e retomada de Area Participante

## Objetivo

Expor no LWC `caseAreasParticipantesPanel` as acoes de pausar e retomar Area Interna manual/Custom, reutilizando os metodos Apex criados no Pacote 22.

## Arquivos alterados

- `force-app/main/default/lwc/caseAreasParticipantesPanel/caseAreasParticipantesPanel.js`
- `force-app/main/default/lwc/caseAreasParticipantesPanel/caseAreasParticipantesPanel.html`
- `force-app/main/default/lwc/caseAreasParticipantesPanel/caseAreasParticipantesPanel.css`
- `force-app/main/default/lwc/caseAreasParticipantesPanel/__tests__/caseAreasParticipantesPanel.test.js`

## Metodos Apex reutilizados

- `AreaParticipanteController.pauseParticipation(request)`
- `AreaParticipanteController.resumeParticipation(request)`

Assinatura real usada pelo LWC: `{ request: { areaParticipanteId } }`.

## Campos e flags usados pelo LWC

- `canManage`
- `isConcluida`
- `isCancelada`
- `statusSLA`
- `caseMilestoneId`

O DTO nao foi alterado neste pacote. Como o DTO atual nao expoe `OrigemSLA__c` nem `TipoAreaParticipante__c`, a UX usa `caseMilestoneId` para nao exibir as acoes em registros Standard espelhados. A validacao funcional continua no Apex.

## Regra de exibicao

- `Pausar`: exibido quando o usuario pode gerenciar, o item nao e Standard espelhado, nao esta concluido/cancelado e `statusSLA` nao e `Pausado`.
- `Retomar`: exibido quando o usuario pode gerenciar, o item nao e Standard espelhado, nao esta concluido/cancelado e `statusSLA` e `Pausado`.

## Confirmacoes de escopo

- Standard nao exibe acoes de pausa/retomada.
- Nenhuma regra de SLA foi alterada.
- Nao houve alteracao em `AreaParticipanteService`, `AreaParticipanteSLAService`, CaseMilestone, Entitlement Process, Flow, Trigger, campos ou Permission Sets.
- Nao foi criada regra de negocio no frontend; o LWC apenas controla visibilidade e chama o backend.

## Testes executados

- `node --check force-app/main/default/lwc/caseAreasParticipantesPanel/caseAreasParticipantesPanel.js`: passou.
- `node --check force-app/main/default/lwc/caseAreasParticipantesPanel/__tests__/caseAreasParticipantesPanel.test.js`: passou.
- Jest LWC: criado, mas nao executado localmente porque `node_modules` nao existe e `sfdx-lwc-jest` nao esta instalado/cacheado.

## Dry-run

- Org: `WILSON_SERVICE`
- Job: `0Afbe00000AAAOXCA5`
- Status: `Succeeded`
- Test level: `NoTestRun`
- Componentes: 1 `LightningComponentBundle`

## Pendencias

- Executar Jest apos `npm install`/restauracao de dependencias locais.
- Se a governanca quiser regra de exibicao 100% derivada do backend, criar em pacote futuro flags `canPause` e `canResume` no DTO.
