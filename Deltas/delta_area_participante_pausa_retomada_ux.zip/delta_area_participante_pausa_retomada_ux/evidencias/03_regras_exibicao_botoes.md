# 03 - Regras de exibicao dos botoes

## Pausar

Exibe quando:

- `panel.canManage = true`
- `caseMilestoneId` vazio
- `isConcluida = false`
- `isCancelada = false`
- `statusSLA` diferente de `Pausado`

## Retomar

Exibe quando:

- `panel.canManage = true`
- `caseMilestoneId` vazio
- `isConcluida = false`
- `isCancelada = false`
- `statusSLA = Pausado`

A validacao funcional permanece em Apex.
