# 04 - Validacao Standard sem acoes

Registros Standard espelhados de CaseMilestone chegam ao painel com `caseMilestoneId` preenchido.

O LWC usa esse indicador para nao exibir `Pausar` nem `Retomar`.

Mesmo que a UI fosse manipulada, o backend do Pacote 22 rejeita registros que nao sejam Area Interna Custom.
