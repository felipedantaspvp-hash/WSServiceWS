# 05 - Validacao Custom Area Interna com acoes

Registros manuais/Custom sem `caseMilestoneId`, nao concluidos e nao cancelados exibem:

- `Pausar` quando `statusSLA` nao e `Pausado`.
- `Retomar` quando `statusSLA` e `Pausado`.

Ao clicar, o LWC exibe loading, chama Apex, mostra toast e atualiza o painel.
