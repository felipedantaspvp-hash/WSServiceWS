# 06 - Testes

## Criados

- `force-app/main/default/lwc/caseAreasParticipantesPanel/__tests__/caseAreasParticipantesPanel.test.js`

Cobertura prevista:

- Exibicao de `Pausar` para Area Interna Custom aberta.
- Exibicao de `Retomar` para Area Interna Custom pausada.
- Ausencia de botoes para Standard.
- Chamada do Apex de pausa.
- Chamada do Apex de retomada.
- Tratamento de erro.

## Executados

- `node --check force-app/main/default/lwc/caseAreasParticipantesPanel/caseAreasParticipantesPanel.js`: passou.
- `node --check force-app/main/default/lwc/caseAreasParticipantesPanel/__tests__/caseAreasParticipantesPanel.test.js`: passou.
- Dry-run `0Afbe00000AAAOXCA5`: `Succeeded`, `NoTestRun`, 1 `LightningComponentBundle`.

## Limitacao local

`npm run test:unit` e `npx --no-install sfdx-lwc-jest` nao executaram porque `node_modules` nao existe e `sfdx-lwc-jest` nao esta instalado/cacheado no workspace.
