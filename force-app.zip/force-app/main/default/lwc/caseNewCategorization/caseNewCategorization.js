import { LightningElement, track, wire } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { decodeDefaultFieldValues } from 'lightning/pageReferenceUtils';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import CASE_OBJECT from '@salesforce/schema/Case';
import getInitialContext from '@salesforce/apex/CaseCreationController.getInitialContext';
import getTreeOptions from '@salesforce/apex/CaseCreationController.getTreeOptions';
import resolveCategorizationSelection from '@salesforce/apex/CaseCreationController.resolveCategorizationSelection';
import getAvailableQueues from '@salesforce/apex/CaseCreationController.getAvailableQueues';
import buildDefaultValues from '@salesforce/apex/CaseCreationController.buildDefaultValues';
import contextSectionLabel from '@salesforce/label/c.CaseNewCategorization_ContextSection';
import categorizacaoLabel from '@salesforce/label/c.Categorizacao';
import destinationSectionLabel from '@salesforce/label/c.CaseNewCategorization_DestinationSection';
import informacoesClienteLabel from '@salesforce/label/c.InformacoesCliente';
import additionalInfoSectionLabel from '@salesforce/label/c.CaseNewCategorization_AdditionalInfoSection';
import detalhesLabel from '@salesforce/label/c.Detalhes';
import descriptionSectionLabel from '@salesforce/label/c.CaseNewCategorization_DescriptionSection';
import casoRelacionadoLabel from '@salesforce/label/c.CasoRelacionado';
import cardTitleLabel from '@salesforce/label/c.CaseNewCategorization_CardTitle';
import subtitleLabel from '@salesforce/label/c.CaseNewCategorization_Subtitle';
import unidadeRecordTypeLabel from '@salesforce/label/c.CaseNewCategorization_UnidadeRecordType';
import unidadeNegocioLabel from '@salesforce/label/c.CaseNewCategorization_UnidadeNegocio';
import tipoCasoLabel from '@salesforce/label/c.CaseNewCategorization_TipoCaso';
import categoriaFieldLabel from '@salesforce/label/c.CaseNewCategorization_Categoria';
import assuntoLabel from '@salesforce/label/c.CaseNewCategorization_Assunto';
import subassuntoLabel from '@salesforce/label/c.CaseNewCategorization_Subassunto';
import destinoLabel from '@salesforce/label/c.CaseNewCategorization_Destino';
import destinationHintAssumeLabel from '@salesforce/label/c.CaseNewCategorization_DestinationHintAssume';
import destinationHintDistributeLabel from '@salesforce/label/c.CaseNewCategorization_DestinationHintDistribute';
import destinationHintCloseLabel from '@salesforce/label/c.CaseNewCategorization_DestinationHintClose';
import queueResolvedLabel from '@salesforce/label/c.CaseNewCategorization_QueueResolved';
import manualQueueLabel from '@salesforce/label/c.CaseNewCategorization_ManualQueue';
import cancelLabel from '@salesforce/label/c.CaseNewCategorization_Cancel';
import loadingLabel from '@salesforce/label/c.CaseNewCategorization_Loading';
import savingLabel from '@salesforce/label/c.CaseNewCategorization_Saving';
import assumeLabel from '@salesforce/label/c.CaseNewCategorization_Assume';
import distributeLabel from '@salesforce/label/c.CaseNewCategorization_Distribute';
import closeLabel from '@salesforce/label/c.CaseNewCategorization_Close';
import assumirBloqueadoHintLabel from '@salesforce/label/c.CaseNewCategorization_AssumirBloqueadoHint';
import errorTitleLabel from '@salesforce/label/c.CaseNewCategorization_ErrorTitle';
import unexpectedLabel from '@salesforce/label/c.CaseNewCategorization_Unexpected';
import prepareFailedLabel from '@salesforce/label/c.CaseNewCategorization_PrepareFailed';
import resolveFailedLabel from '@salesforce/label/c.CaseNewCategorization_ResolveFailed';
import saveLabel from '@salesforce/label/c.CaseNewCategorization_Save';
import continueButtonLabel from '@salesforce/label/c.CaseNewCategorization_ContinueButton';
import successTitleLabel from '@salesforce/label/c.CaseNewCategorization_SuccessTitle';
import successMsgLabel from '@salesforce/label/c.CaseNewCategorization_SuccessMsg';
import createFailedLabel from '@salesforce/label/c.CaseNewCategorization_CreateFailed';

// Replica, por Unidade de Negócio, as seções/campos/regras de visibilidade "preenchíveis na criação"
// da Lightning Page real (Dynamic Forms) daquela unidade — extraído de LP_Atendimento_Salvador em
// 2026-06-25. Os campos que o próprio wizard já resolve (Unidade, Tipo, Categoria, Assunto,
// Subassunto, Owner, Etapa) ficam de fora de propósito, pois são injetados via buildDefaultValues
// no submit, não preenchidos aqui (a exceção é Origin, que o wizard pré-define como "Manual" mas
// fica editável aqui — o valor escolhido pelo agente prevalece sobre o default no submit).
// Campos somente leitura/auditoria (CreatedDate, SuppliedEmail, CreatedById, etc.) também ficam
// fora — não fazem sentido na criação.
// `visibleWhen`/seção e campo recebem o contexto {tipoCaso, categoria, modalidade} com os valores
// atuais (categoria/tipoCaso vêm do wizard; modalidade vem do próprio campo desta seção, em tempo real).
// Atualizar aqui sempre que a Lightning Page da unidade correspondente mudar. Unidades sem entrada
// aqui caem no fallback de Page Layout puro (lightning-record-form).
const NAO_ELOGIO = (ctx) => ctx.tipoCaso !== 'Elogio';

// Gera uma cópia independente da config "padrão Salvador" — usado como placeholder para as
// demais Unidades de Negócio até que cada uma tenha sua própria Lightning Page configurada e as
// regras de negócio reais possam ser extraídas e ajustadas por unidade (ver comentário acima).
// Retornar um array/objeto novo a cada chamada evita que editar uma unidade afete as outras.
function buildSalvadorPatternSections() {
    return [
        {
            title: informacoesClienteLabel,
            rows: [
                [{ field: 'AccountId', required: true }, { field: 'ContactId', required: true }],
                [{ field: 'Representante__c' }, { field: 'ParentId' }]
            ]
        },
        {
            title: additionalInfoSectionLabel,
            rows: [
                [{ field: 'Origin', required: true, value: 'Manual' }, { field: 'Priority', value: (ctx) => ctx.prioridade }],
                [{ field: 'Modalidade__c', required: true, visibleWhen: NAO_ELOGIO }, { field: 'Container__c', required: true, visibleWhen: NAO_ELOGIO }],
                [{ field: 'AreasParticipantes__c', required: true }, null]
            ]
        },
        {
            title: detalhesLabel,
            // União das condições de todos os campos abaixo — garante que a seção nunca fique
            // oculta enquanto algum campo dela teria conteúdo a mostrar (a regra original da
            // Lightning Page tinha essa mesma intenção, mas faltava "Modalidade = Importação"
            // no nível da seção, o que escondia BL__c mesmo quando deveria aparecer).
            visibleWhen: (ctx) =>
                ctx.tipoCaso === 'Elogio' ||
                (NAO_ELOGIO(ctx) &&
                    (ctx.modalidade === 'Importação' ||
                        ctx.modalidade === 'Cabotagem Embarque' ||
                        ctx.modalidade === 'Exportação' ||
                        ctx.categoria === 'Acesso ao Porto')),
            // Um campo por linha (sempre na coluna esquerda) — como a visibilidade de cada campo é
            // independente, pares lado a lado deixavam a coluna direita vazia/flutuando com
            // frequência. Mantém o layout estável e previsível nessa seção condicional.
            rows: [
                [{ field: 'Colaborador__c', visibleWhen: (ctx) => ctx.tipoCaso === 'Elogio' }, null],
                [{ field: 'BL__c', visibleWhen: (ctx) => NAO_ELOGIO(ctx) && ctx.modalidade === 'Importação' }, null],
                [{ field: 'Booking__c', visibleWhen: (ctx) => NAO_ELOGIO(ctx) && (ctx.modalidade === 'Cabotagem Embarque' || ctx.modalidade === 'Exportação') }, null],
                [{
                    field: 'EvidenciaGatePlaca__c',
                    visibleWhen: (ctx) =>
                        NAO_ELOGIO(ctx) &&
                        ((ctx.categoria && /porto|gate/i.test(ctx.categoria)) ||
                            (ctx.subassunto && /gate/i.test(ctx.subassunto)))
                }, null]
            ]
        },
        {
            title: descriptionSectionLabel,
            rows: [[{ field: 'Description', required: true, fullWidth: true }, null]]
        }
    ];
}

// Réplica para "Atendimento Tecon Rio Grande" — extraído de LP_Atendimento_RioGrande em
// 2026-06-26. Diferente do padrão Salvador, as regras dessa unidade dependem fortemente de
// Assunto__c (não só Categoria__c/Subassunto__c), por isso usa ctx.assunto (ver detailContext).
// Vários campos apareciam em mais de uma seção/instância na Lightning Page original com
// condições de visibilidade distintas (ex.: Container__c em 3 instâncias, ViagemNavio__c em 2,
// Booking__c em 2, DataNascimento__c em 2) — aqui cada campo existe uma única vez, com o
// `visibleWhen` cobrindo a união (OR) de todas as condições originais, já que o input em si é o
// mesmo, só a regra de exibição mudava por instância na Lightning Page (lá isso era necessário
// por causa do limite de 10 critérios por `visibilityRule`; aqui não há essa restrição).
function buildRioGrandeSections() {
    const isCadastroPF = (ctx) => ctx.assunto === 'Cadastro Pessoa Física';
    const isCadastroPJ = (ctx) => ctx.assunto === 'Cadastro Pessoa Jurídica';
    const isCargasPerigosas = (ctx) => ctx.assunto === 'Cargas perigosas / Especiais';
    const isPJAtualizacao = (ctx) => isCadastroPJ(ctx) && ctx.subassunto === 'Atualização';
    const isEDIFalha = (ctx) =>
        ctx.assunto === 'EDI' &&
        (ctx.subassunto === 'Falha de envio' || ctx.subassunto === 'Falha de recebimento' || ctx.subassunto === 'Divergência de dados');

    return [
        {
            title: informacoesClienteLabel,
            rows: [
                [{ field: 'AccountId', required: true }, { field: 'ContactId', required: true }],
                [{ field: 'Representante__c' }, { field: 'ParentId' }]
            ]
        },
        {
            title: additionalInfoSectionLabel,
            rows: [
                [{ field: 'Origin', required: true, value: 'Manual' }, { field: 'Priority', value: (ctx) => ctx.prioridade }],
                [{ field: 'Nivel__c', required: true }, null]
            ]
        },
        {
            title: detalhesLabel,
            // Sem visibleWhen no nível da seção: o filtro de linhas em caseDetailSections já
            // remove a seção inteira quando nenhum dos campos abaixo bate sua condição.
            rows: [
                [{
                    field: 'Motivo__c',
                    required: true,
                    visibleWhen: (ctx) =>
                        ctx.categoria === 'Faturamento' &&
                        (ctx.assunto === 'Ajustes de OS' || ctx.assunto === 'Nota Fiscal') &&
                        (ctx.subassunto === 'CNPJ' || ctx.subassunto === 'Cancelamento')
                }, null],
                [{ field: 'CPF__c', required: true, visibleWhen: isCadastroPF }, null],
                [{ field: 'CNPJ__c', required: true, visibleWhen: (ctx) => isCadastroPJ(ctx) || ctx.assunto === 'WS Acesso' }, null],
                [{
                    field: 'DataNascimento__c',
                    visibleWhen: (ctx) =>
                        isCadastroPF(ctx) &&
                        (ctx.subassunto === 'Criação' ||
                            ctx.subassunto === 'Status de aprovação' ||
                            ctx.subassunto === 'Exclusão' ||
                            ctx.subassunto === 'Atualização')
                }, null],
                [{ field: 'Atividade__c', required: true, visibleWhen: (ctx) => isCadastroPJ(ctx) && ctx.subassunto === 'Criação' }, null],
                [{ field: 'NovaRazaoSocial__c', visibleWhen: isPJAtualizacao }, null],
                [{ field: 'NovoEndereco__c', visibleWhen: isPJAtualizacao }, null],
                [{ field: 'NovoEmail__c', visibleWhen: isPJAtualizacao }, null],
                [{ field: 'EmailIncluido__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Atualização de E-mail' }, null],
                [{ field: 'EmailExcluido__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Atualização de E-mail' }, null],
                [{ field: 'NomenclaturaAntiga__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Nomenclatura' }, null],
                [{ field: 'NomenclaturaNova__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Nomenclatura' }, null],
                [{ field: 'SetorResponsavel__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Setor Responsável' }, null],
                [{
                    field: 'NumeroPropostaSalesforce__c',
                    required: true,
                    visibleWhen: (ctx) =>
                        ctx.assunto === 'Proposta Comercial' ||
                        (ctx.categoria === 'Faturamento' && ctx.assunto === 'Nota Fiscal' && ctx.subassunto === 'Informações')
                }, null],
                [{
                    field: 'NumeroNotaFiscal__c',
                    required: true,
                    visibleWhen: (ctx) => ctx.assunto === 'Nota Fiscal' && (ctx.subassunto === 'Cancelamento' || ctx.subassunto === 'Informações')
                }, null],
                [{
                    field: 'NumeroFatura__c',
                    required: true,
                    visibleWhen: (ctx) => ctx.assunto === 'Fatura' || ctx.assunto === 'Contas a pagar'
                }, null],
                [{
                    field: 'NumeroPODraft__c',
                    visibleWhen: (ctx) =>
                        ctx.categoria === 'Faturamento' && (ctx.subassunto === 'PO / Draft' || ctx.subassunto === 'Solicitação para faturar')
                }, null],
                [{ field: 'NumeroOrdemServico__c', required: true, visibleWhen: (ctx) => ctx.assunto === 'Ajustes de OS' }, null],
                [{
                    field: 'ViagemNavio__c',
                    visibleWhen: (ctx) =>
                        ctx.subassunto === 'Lista de navio' ||
                        (ctx.assunto === 'Navio' && ctx.subassunto === 'LAR') ||
                        (ctx.categoria === 'Faturamento' && (ctx.subassunto === 'PO / Draft' || ctx.subassunto === 'Solicitação para faturar')) ||
                        (ctx.assunto === 'Relatórios' && ctx.subassunto === 'Relatório de Movimentações')
                }, null],
                [{
                    field: 'Booking__c',
                    visibleWhen: (ctx) =>
                        ctx.assunto === 'Booking' || (ctx.assunto === 'Relatórios' && ctx.subassunto === 'Consulta Booking') || isEDIFalha(ctx)
                }, null],
                [{
                    field: 'Container__c',
                    visibleWhen: (ctx) =>
                        ['Navio', 'Pesagem', 'Presença de carga', 'Relatórios'].includes(ctx.assunto) ||
                        ['Ticket de Pesagem', 'Consulta Contêiner', 'EIR'].includes(ctx.subassunto) ||
                        ctx.assunto === 'Avaria' ||
                        (isCargasPerigosas(ctx) && ctx.subassunto !== 'Colocação / Remoção Label') ||
                        isEDIFalha(ctx) ||
                        ctx.assunto === 'Solicitação para faturar' ||
                        (ctx.assunto === 'Nota Fiscal' && ctx.subassunto === 'Previsão de Emissão') ||
                        ctx.assunto === 'PO / Draft' ||
                        ctx.assunto === 'Agendamento'
                }, null],
                [{ field: 'NumeroLacre__c', required: true, visibleWhen: (ctx) => ctx.subassunto === 'Lacres' }, null],
                [{ field: 'NumeroLacreAlterado__c', visibleWhen: (ctx) => ctx.subassunto === 'Lacres' }, null],
                [{ field: 'Bat__c', required: true, visibleWhen: (ctx) => ctx.assunto === 'Pátio' }, null],
                [{ field: 'PlacaCavalo__c', visibleWhen: (ctx) => ctx.assunto === 'Agendamento' || ctx.assunto === 'Pátio' }, null],
                [{ field: 'ResponsavelAvaria__c', required: true, visibleWhen: (ctx) => ctx.assunto === 'Avaria' }, null],
                [{
                    field: 'IMO__c',
                    visibleWhen: (ctx) =>
                        isCargasPerigosas(ctx) && (ctx.subassunto === 'Procedimentos' || ctx.subassunto === 'Cargas Aceitas/ Não Aceitas')
                }, null],
                [{ field: 'Mercadoria__c', visibleWhen: isCargasPerigosas }, null],
                [{ field: 'UN__c', visibleWhen: isCargasPerigosas }, null],
                [{ field: 'NomeDaTela__c', visibleWhen: (ctx) => ctx.assunto === 'Teconline' }, null],
                [{ field: 'DUE__c', visibleWhen: (ctx) => ctx.assunto === 'Presença de carga' }, null],
                [{ field: 'TipoArquivo__c', visibleWhen: isEDIFalha }, null],
                [{ field: 'Observacoes__c' }, null]
            ]
        },
        {
            title: descriptionSectionLabel,
            rows: [[{ field: 'Description', required: true, fullWidth: true }, null]]
        }
    ];
}

// Extraído de LP_Atendimento_CentroLogistico em 2026-07-02. A LP divide "Detalhes" em três
// seções físicas (section7/10/8) por limitação de 10 critérios por visibilityRule; aqui
// consolidamos tudo em uma seção, mesclando instâncias duplicadas do mesmo campo em um único
// visibleWhen. Campos de fórmula (TipoCasoRelacionado__c etc.) ficam de fora por não existirem
// antes do save. Regra de layout: nenhum campo sozinho no lado direito da linha.
function buildCentroLogisticoSections() {
    // ---- DTA__c ----
    // s7(Informação): ApoioAduaneiro+(Confirmar prazo vencimento OR Confirmar liberação MAPA)
    //                 OR Operação+Encaminhar dados do recebimento - Alfandegado
    // s10(Solicitação): Operação+foto avaria OR ServiçosEsp+(all except Enviar relatório paletização)
    //                   OR Transporte+revisão CTE
    // s8(Solicitação): ApoioAduaneiro (all) OR Documentação+vários assuntos
    const showDTA = (ctx) => {
        if (ctx.tipoCaso === 'Informação') {
            return (ctx.categoria === 'Apoio Aduaneiro' &&
                    (ctx.assunto === 'Confirmar prazo de vencimento' ||
                     ctx.assunto === 'Confirmar liberação do MAPA')) ||
                   (ctx.categoria === 'Operação' &&
                    ctx.assunto === 'Encaminhar dados do recebimento - Alfandegado');
        }
        if (ctx.tipoCaso === 'Solicitação') {
            return (ctx.categoria === 'Operação' && ctx.assunto === 'Encaminhar foto de avaria') ||
                   (ctx.categoria === 'Serviços específicos' &&
                    ctx.assunto !== 'Enviar relatório de paletização') ||
                   (ctx.categoria === 'Transporte' &&
                    ctx.subassunto === 'Pedido de revisão de CTE') ||
                   ctx.categoria === 'Apoio Aduaneiro' ||
                   (ctx.categoria === 'Documentação' && (
                       ctx.assunto === 'Encaminhar CDA (Certificado Deposito Aduaneiro)' ||
                       ctx.assunto === 'Petição' ||
                       ctx.assunto === 'Solicitar assinatura de carta protesto' ||
                       ctx.assunto === 'Enviar ticket de pesagem' ||
                       ctx.assunto === 'Solicitar repesagem de carga' ||
                       ctx.assunto === 'Solicitar documentos ou retificação documental' ||
                       ctx.assunto === 'Encaminhar TFA (Termo de Falta e Avaria)'
                   ));
        }
        return false;
    };

    // ---- Conhecimento__c ----
    // s7(Informação): ApoioAduaneiro+(Confirmar prazo vencimento OR Confirmar MAPA)
    //                 OR Operação+Alfandegado
    // s10(Solicitação): Operação+(foto avaria OR Entreposto) OR POAlfandegado
    //                   OR ServiçosEsp+(Realizar/SolicitarPacking/Relatório/Planilhas/Comunicar/InformarStatus)
    // s8(Solicitação): Documentação+(foto/TFA/CDA/CartaProtesto/TicketPesagem/SolicitarDocs/Petição+sub)
    //                  OR Financeiro+Envio reenvio fatura/prévia
    const showConhecimento = (ctx) => {
        if (ctx.tipoCaso === 'Informação') {
            return (ctx.categoria === 'Apoio Aduaneiro' &&
                    (ctx.assunto === 'Confirmar prazo de vencimento' ||
                     ctx.assunto === 'Confirmar liberação do MAPA')) ||
                   (ctx.categoria === 'Operação' &&
                    ctx.assunto === 'Encaminhar dados do recebimento - Alfandegado');
        }
        if (ctx.tipoCaso === 'Solicitação') {
            return (ctx.categoria === 'Operação' && (
                        ctx.assunto === 'Encaminhar foto de avaria' ||
                        ctx.assunto === 'Solicitar separação de carga entreposto'
                   )) ||
                   ctx.categoria === 'Planejamento Operacional Alfandegado' ||
                   (ctx.categoria === 'Serviços específicos' && (
                       ctx.assunto === 'Realizar acompanhamento (modelo distinto)' ||
                       ctx.assunto === 'Solicitar packing list para despachante' ||
                       ctx.assunto === 'Enviar relatório de paletização' ||
                       ctx.assunto === 'Gerenciar planilhas de etiquetagem' ||
                       ctx.assunto === 'Comunicar programação' ||
                       ctx.assunto === 'Informar status de remoção de carga'
                   )) ||
                   (ctx.categoria === 'Documentação' && (
                       ctx.subassunto === 'Enviar foto' ||
                       ctx.assunto === 'Encaminhar TFA (Termo de Falta e Avaria)' ||
                       ctx.assunto === 'Encaminhar CDA (Certificado Deposito Aduaneiro)' ||
                       ctx.assunto === 'Solicitar assinatura de carta protesto' ||
                       ctx.assunto === 'Enviar ticket de pesagem' ||
                       ctx.assunto === 'Solicitar documentos ou retificação documental' ||
                       (ctx.assunto === 'Petição' && (
                           ctx.subassunto === 'Retirar pontuação de atraso' ||
                           ctx.subassunto === 'Retificação documental' ||
                           ctx.subassunto === 'Temas diversos'
                       ))
                   )) ||
                   (ctx.categoria === 'Financeiro' &&
                    ctx.subassunto === 'Envio ou reenvio da fatura ou prévia');
        }
        return false;
    };

    // ---- NumeroNotaFiscal__c ----
    // s7(Informação): ApoioAduaneiro+Confirmar liberação OR Operação+(Alfandegado OR CD)
    //                 OR Financeiro+Fatura ou prévia
    // s8(Solicitação): Agendamento+Liberar janela OR Documentação+vários OR Financeiro+vários
    // s10(Solicitação): ServiçosEsp+(Realizar/GerenciarRecebimento/ElaborarRomaneio)
    const showNumeroNotaFiscal = (ctx) => {
        if (ctx.tipoCaso === 'Informação') {
            return (ctx.categoria === 'Apoio Aduaneiro' &&
                    ctx.assunto === 'Confirmar liberação de carga') ||
                   (ctx.categoria === 'Operação' && (
                       ctx.assunto === 'Encaminhar dados do recebimento - Alfandegado' ||
                       ctx.assunto === 'Encaminhar dados do recebimento - CD'
                   )) ||
                   (ctx.categoria === 'Financeiro' && ctx.assunto === 'Fatura ou prévia');
        }
        if (ctx.tipoCaso === 'Solicitação') {
            return (ctx.categoria === 'Agendamento' && ctx.assunto === 'Liberar janela extra') ||
                   (ctx.categoria === 'Documentação' && (
                       ctx.subassunto === 'Enviar foto' ||
                       ctx.assunto === 'Enviar ticket de pesagem' ||
                       (ctx.assunto === 'Petição' && (
                           ctx.subassunto === 'Retificação documental' ||
                           ctx.subassunto === 'Temas diversos'
                       ))
                   )) ||
                   (ctx.categoria === 'Financeiro' && (
                       ctx.subassunto === 'Faturas em aberto' ||
                       ctx.subassunto === 'Isenção / Revisão de fatura' ||
                       ctx.subassunto === 'Envio ou reenvio da fatura ou prévia' ||
                       ctx.subassunto === 'Identificar pagamento da prévia'
                   )) ||
                   (ctx.categoria === 'Serviços específicos' && (
                       ctx.assunto === 'Realizar acompanhamento (modelo distinto)' ||
                       ctx.assunto === 'Gerenciar recebimento de carga' ||
                       ctx.assunto === 'Elaborar romaneio e packing'
                   ));
        }
        return false;
    };

    // ---- DUE__c ----
    // s7(Informação): ApoioAduaneiro+Confirmar liberação
    // s8(Solicitação): Agendamento+Liberar janela OR Documentação+Petição+Retificação documental
    const showDUE = (ctx) =>
        (ctx.tipoCaso === 'Informação' && ctx.categoria === 'Apoio Aduaneiro' &&
         ctx.assunto === 'Confirmar liberação de carga') ||
        (ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Agendamento' && ctx.assunto === 'Liberar janela extra') ||
            (ctx.categoria === 'Documentação' && ctx.assunto === 'Petição' &&
             ctx.subassunto === 'Retificação documental')
        ));

    // ---- DI_DUIMP__c ----
    // s7(Informação): ApoioAduaneiro+Confirmar liberação OR POAlfandegado
    // s10(Solicitação): Operação+Entreposto OR Transporte+(Pedido entrega OR revisão CTE)
    // s8(Solicitação): Agendamento+Liberar janela OR Documentação+vários OR Financeiro+vários
    const showDI_DUIMP = (ctx) => {
        if (ctx.tipoCaso === 'Informação') {
            return (ctx.categoria === 'Apoio Aduaneiro' &&
                    ctx.assunto === 'Confirmar liberação de carga') ||
                   ctx.categoria === 'Planejamento Operacional Alfandegado';
        }
        if (ctx.tipoCaso === 'Solicitação') {
            return (ctx.categoria === 'Operação' &&
                    ctx.assunto === 'Solicitar separação de carga entreposto') ||
                   (ctx.categoria === 'Transporte' && (
                       ctx.subassunto === 'Pedido de entrega de carga' ||
                       ctx.subassunto === 'Pedido de revisão de CTE'
                   )) ||
                   (ctx.categoria === 'Agendamento' && ctx.assunto === 'Liberar janela extra') ||
                   (ctx.categoria === 'Documentação' && (
                       ctx.assunto === 'Solicitar documentos ou retificação documental' ||
                       (ctx.assunto === 'Petição' && (
                           ctx.subassunto === 'Enviar foto' ||
                           ctx.subassunto === 'Retificação documental' ||
                           ctx.subassunto === 'Temas diversos'
                       ))
                   )) ||
                   (ctx.categoria === 'Financeiro' && (
                       ctx.subassunto === 'Envio ou reenvio da fatura ou prévia' ||
                       ctx.subassunto === 'Identificar pagamento da prévia' ||
                       ctx.subassunto === 'Faturas em aberto' ||
                       ctx.subassunto === 'Isenção / Revisão de fatura'
                   ));
        }
        return false;
    };

    // ---- DA__c ----
    // s8(Solicitação): Documentação+CDA
    // s10(Solicitação): Operação+Entreposto
    const showDA = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Documentação' &&
             ctx.assunto === 'Encaminhar CDA (Certificado Deposito Aduaneiro)') ||
            (ctx.categoria === 'Operação' &&
             ctx.assunto === 'Solicitar separação de carga entreposto')
        );

    // ---- Processo_DTA_DI_DUIMP_DUE_NF__c ----
    // s7(Informação): Transporte (all)
    // s10(Solicitação): Transporte+(Pedido coleta OR Solicitação CTE)
    const showProcesso = (ctx) =>
        ctx.categoria === 'Transporte' && (
            ctx.tipoCaso === 'Informação' ||
            (ctx.tipoCaso === 'Solicitação' && (
                ctx.subassunto === 'Pedido de coleta de carga' ||
                ctx.subassunto === 'Solicitação de CTE'
            ))
        );

    // ---- CTE__c / NF_DUE__c ---- (ambos: Solicitação+Transporte+Pedido revisão CTE)
    const showTransporteRevisaoCTE = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Transporte' &&
        ctx.subassunto === 'Pedido de revisão de CTE';

    // ---- Chave_de_Acesso_DUIMP__c ---- (Solicitação+POAlfandegado)
    // ---- Invoice__c ---- (Solicitação: Operação+Entreposto OR Transporte+Coleta OR ServiçosEsp+... OR ApoioAduaneiro)
    const showInvoice = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Operação' &&
             ctx.assunto === 'Solicitar separação de carga entreposto') ||
            (ctx.categoria === 'Transporte' && ctx.subassunto === 'Pedido de coleta de carga') ||
            (ctx.categoria === 'Serviços específicos' && (
                ctx.assunto === 'Gerenciamento de programação de Exportação' ||
                ctx.assunto === 'Enviar comprovante de entrega'
            )) ||
            ctx.categoria === 'Apoio Aduaneiro'
        );

    // ---- Packing_List__c ---- (Solicitação: ApoioAduaneiro OR Operação+Entreposto
    //                            OR Transporte+Coleta OR ServiçosEsp+(GerenciarReceb/ElaborarRom))
    const showPackingList = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            ctx.categoria === 'Apoio Aduaneiro' ||
            (ctx.categoria === 'Operação' &&
             ctx.assunto === 'Solicitar separação de carga entreposto') ||
            (ctx.categoria === 'Transporte' && ctx.subassunto === 'Pedido de coleta de carga') ||
            (ctx.categoria === 'Serviços específicos' && (
                ctx.assunto === 'Gerenciar recebimento de carga' ||
                ctx.assunto === 'Elaborar romaneio e packing'
            ))
        );

    // ---- NumeroFatura__c ----
    // s7(Informação): Financeiro+Fatura ou prévia
    // s8(Solicitação): Financeiro+Isenção/Revisão fatura
    // s10(Solicitação): ServiçosEsp+Realizar acompanhamento
    const showNumeroFatura = (ctx) =>
        (ctx.tipoCaso === 'Informação' && ctx.categoria === 'Financeiro' &&
         ctx.assunto === 'Fatura ou prévia') ||
        (ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Financeiro' &&
             ctx.subassunto === 'Isenção / Revisão de fatura') ||
            (ctx.categoria === 'Serviços específicos' &&
             ctx.assunto === 'Realizar acompanhamento (modelo distinto)')
        ));

    // ---- Comissaria__c ----
    // s7(Informação): Financeiro+Proposta comercial / Cadastro
    // s8(Solicitação): Comercial (all) OR Financeiro+Proposta comercial / Cadastro
    const showComissaria = (ctx) =>
        (ctx.tipoCaso === 'Informação' && ctx.categoria === 'Financeiro' &&
         ctx.assunto === 'Proposta comercial / Cadastro') ||
        (ctx.tipoCaso === 'Solicitação' && (
            ctx.categoria === 'Comercial' ||
            (ctx.categoria === 'Financeiro' && ctx.assunto === 'Proposta comercial / Cadastro')
        ));

    // ---- CNPJ__c ----
    // s7(Informação): Financeiro+Proposta comercial / Cadastro
    // s8(Solicitação): Agendamento+(Cadastrar empresas OR Aprovar cadastro)
    //                  OR Financeiro+(Identificar pagamento OR Proposta comercial / Cadastro)
    const showCNPJ = (ctx) =>
        (ctx.tipoCaso === 'Informação' && ctx.categoria === 'Financeiro' &&
         ctx.assunto === 'Proposta comercial / Cadastro') ||
        (ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Agendamento' && (
                ctx.assunto === 'Cadastrar empresas e clientes' ||
                ctx.assunto === 'Aprovar cadastro'
            )) ||
            (ctx.categoria === 'Financeiro' && (
                ctx.subassunto === 'Identificar pagamento da prévia' ||
                ctx.assunto === 'Proposta comercial / Cadastro'
            ))
        ));

    // ---- PeriodoQuestionado__c ---- (Solicitação+Financeiro+Faturas em aberto)
    // ---- Comprovante_de_Vinculo__c ---- (Solicitação+Financeiro+Solicitação de proposta comercial)

    // ---- Empresa__c / E_mail__c / Telefone__c ---- (Agendamento+Cadastrar/Aprovar)
    const isAgendamentoCadastro = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Agendamento' && (
            ctx.assunto === 'Cadastrar empresas e clientes' ||
            ctx.assunto === 'Aprovar cadastro'
        );

    // ---- PlacaCavalo__c ----
    // s7(Informação): Agendamento+Acompanhar veículo sem agendamento
    // s8(Solicitação): Agendamento+(Acompanhar divergências OR Acompanhar veículo)
    // s10(Solicitação): ServiçosEsp+Atualizar JDA
    const showPlacaCavalo = (ctx) =>
        (ctx.categoria === 'Agendamento' && (
            ctx.assunto === 'Acompanhar divergências de agendamento' ||
            ctx.assunto === 'Acompanhar veículo sem agendamento'
        )) ||
        (ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
         ctx.assunto === 'Atualizar JDA com agendamentos');

    // ---- Transportadora__c ----
    // s8(Solicitação): Agendamento+(Acompanhar divergências OR Acompanhar veículo)
    //                  OR ServiçosEsp+Realizar acompanhamento
    // s10(Solicitação): ServiçosEsp+(Realizar acompanhamento OR Atualizar JDA)
    const showTransportadora = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Agendamento' && (
                ctx.assunto === 'Acompanhar divergências de agendamento' ||
                ctx.assunto === 'Acompanhar veículo sem agendamento'
            )) ||
            (ctx.categoria === 'Serviços específicos' && (
                ctx.assunto === 'Realizar acompanhamento (modelo distinto)' ||
                ctx.assunto === 'Atualizar JDA com agendamentos'
            ))
        );

    // ---- Motorista__c ----
    // s7(Informação): Agendamento+Acompanhar veículo sem agendamento
    // s10(Solicitação): ServiçosEsp+Atualizar JDA
    const showMotorista = (ctx) =>
        (ctx.tipoCaso === 'Informação' && ctx.categoria === 'Agendamento' &&
         ctx.assunto === 'Acompanhar veículo sem agendamento') ||
        (ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
         ctx.assunto === 'Atualizar JDA com agendamentos');

    // ---- Container__c ----
    // s8(Solicitação): Documentação+Solicitar assinatura comprovante entrega
    // s10(Solicitação): ServiçosEsp+(SolicitarPacking OR GerenciamentoExportação OR
    //                               EnviarComprovante OR LançarServiços)
    const showContainer = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Documentação' &&
             ctx.assunto === 'Solicitar assinatura de comprovante de entrega') ||
            (ctx.categoria === 'Serviços específicos' && (
                ctx.assunto === 'Solicitar packing list para despachante' ||
                ctx.assunto === 'Gerenciamento de programação de Exportação' ||
                ctx.assunto === 'Enviar comprovante de entrega' ||
                ctx.assunto === 'Lançar serviços e custos adicionais no ECM'
            ))
        );

    // ---- Data_da_Entrega__c ----
    // s10(Solicitação): Transporte+(Pedido coleta OR Pedido entrega) OR ServiçosEsp+Enviar comprovante
    const showDataEntrega = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Transporte' && (
                ctx.subassunto === 'Pedido de coleta de carga' ||
                ctx.subassunto === 'Pedido de entrega de carga'
            )) ||
            (ctx.categoria === 'Serviços específicos' &&
             ctx.assunto === 'Enviar comprovante de entrega')
        );

    // ---- Data_Inicial__c / Data_Final__c ---- (mesma condição)
    // s8(Solicitação): Documentação+(Relatório diversos OR Relatório personalizado)
    //                  OR Financeiro+Relatório de custos
    const showDataInicialFinal = (ctx) =>
        ctx.tipoCaso === 'Solicitação' && (
            (ctx.categoria === 'Documentação' && (
                ctx.subassunto === 'Relatório diversos' ||
                ctx.subassunto === 'Relatório personalizado'
            )) ||
            (ctx.categoria === 'Financeiro' && ctx.subassunto === 'Relatório de custos')
        );

    // ---- Data_Remocao__c ---- (s8 Solicitação: Categoria NE ApoioAduaneiro)
    // Escopo: apenas as categorias presentes na section8 (não inclui Operação/QSMS/Transporte/
    // POAlfandegado/ServiçosEsp/Portal, pois esses estão na section10 sem este campo).
    const showDataRemocao = (ctx) =>
        ctx.tipoCaso === 'Solicitação' &&
        ['Documentação', 'Agendamento', 'Atendimento', 'Comercial', 'Financeiro'].includes(ctx.categoria);

    return [
        {
            title: informacoesClienteLabel,
            rows: [
                [{ field: 'AccountId', required: true }, { field: 'ContactId', required: true }],
                [{ field: 'Representante__c' }, { field: 'ParentId' }]
            ]
        },
        {
            title: additionalInfoSectionLabel,
            rows: [
                [{ field: 'Origin', required: true, value: 'Manual' },
                 { field: 'Priority', value: (ctx) => ctx.prioridade }]
            ]
        },
        {
            title: detalhesLabel,
            rows: [
                // Documentos de carga (Apoio Aduaneiro / Operação)
                [{ field: 'DTA__c', required: true, visibleWhen: showDTA },
                 { field: 'Conhecimento__c', required: true, visibleWhen: showConhecimento }],
                [{ field: 'NumeroNotaFiscal__c', required: true, visibleWhen: showNumeroNotaFiscal },
                 { field: 'DUE__c', required: true, visibleWhen: showDUE }],
                [{ field: 'DI_DUIMP__c', required: true, visibleWhen: showDI_DUIMP },
                 { field: 'DA__c', required: true, visibleWhen: showDA }],
                // Apoio Aduaneiro (Solicitação)
                [{ field: 'BL__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Apoio Aduaneiro' },
                 { field: 'Anuencia_MAPA__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Apoio Aduaneiro' }],
                [{ field: 'Invoice__c', visibleWhen: showInvoice },
                 { field: 'Packing_List__c', visibleWhen: showPackingList }],
                // Transporte / Planejamento Operacional Alfandegado
                [{ field: 'Processo_DTA_DI_DUIMP_DUE_NF__c', required: true, visibleWhen: showProcesso },
                 { field: 'CTE__c', required: true, visibleWhen: showTransporteRevisaoCTE }],
                [{ field: 'NF_DUE__c', visibleWhen: showTransporteRevisaoCTE },
                 { field: 'Chave_de_Acesso_DUIMP__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Planejamento Operacional Alfandegado' }],
                // Financeiro / Comercial
                [{ field: 'NumeroFatura__c', required: true, visibleWhen: showNumeroFatura },
                 { field: 'Comissaria__c', required: true, visibleWhen: showComissaria }],
                [{ field: 'PeriodoQuestionado__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Financeiro' &&
                                        ctx.subassunto === 'Faturas em aberto' },
                 { field: 'Comprovante_de_Vinculo__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Financeiro' &&
                                        ctx.subassunto === 'Solicitação de proposta comercial' }],
                // Agendamento — cadastro (CNPJ usa showCNPJ completo para cobrir Financeiro tb;
                // Telefone só mostra para Agendamento — quando o contexto for Financeiro, CNPJ
                // fica visível no esquerdo e Telefone oculto no direito, o que é válido)
                [{ field: 'Empresa__c', required: true, visibleWhen: isAgendamentoCadastro },
                 { field: 'E_mail__c', required: true, visibleWhen: isAgendamentoCadastro }],
                [{ field: 'CNPJ__c', visibleWhen: showCNPJ },
                 { field: 'Telefone__c', visibleWhen: isAgendamentoCadastro }],
                // Agendamento — acompanhamento / janela
                [{ field: 'PlacaCavalo__c', required: true, visibleWhen: showPlacaCavalo },
                 { field: 'Transportadora__c', required: true, visibleWhen: showTransportadora }],
                [{ field: 'ID__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Agendamento' &&
                                        ctx.assunto === 'Acompanhar divergências de agendamento' },
                 { field: 'Motorista__c', visibleWhen: showMotorista }],
                // Data_e_Hora_Pretendida só para Liberar janela extra (DUE já está na row de Documentos)
                [{ field: 'Data_e_Hora_Pretendida__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Agendamento' &&
                                        ctx.assunto === 'Liberar janela extra' }, null],
                // Container / transporte físico
                [{ field: 'Container__c', required: true, visibleWhen: showContainer },
                 { field: 'NumeroLacre__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Gerenciamento de programação de Exportação' }],
                [{ field: 'Booking__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Gerenciamento de programação de Exportação' },
                 { field: 'Tara__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Gerenciamento de programação de Exportação' }],
                // Datas
                [{ field: 'Data_da_Entrega__c', required: true, visibleWhen: showDataEntrega },
                 { field: 'Data_Coleta__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Realizar acompanhamento (modelo distinto)' }],
                [{ field: 'Data_Chegada__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' && (
                       ctx.assunto === 'Realizar acompanhamento (modelo distinto)' ||
                       ctx.assunto === 'Comunicar programação' ||
                       ctx.assunto === 'Informar status de remoção de carga'
                   ) },
                 { field: 'Horario_da_Entrega__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Transporte' &&
                                        ctx.subassunto === 'Pedido de entrega de carga' }],
                // Data_Remocao (esquerda, broad) + Data__c (direita, Atendimento only). Quando
                // não é Atendimento, só Data_Remocao aparece — field sozinho na esquerda é válido.
                [{ field: 'Data_Remocao__c', required: true, visibleWhen: showDataRemocao },
                 { field: 'Data__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Atendimento' }],
                [{ field: 'Data_Inicial__c', required: true, visibleWhen: showDataInicialFinal },
                 { field: 'Data_Final__c', required: true, visibleWhen: showDataInicialFinal }],
                // Portal Logístico
                [{ field: 'Nome__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Portal Logístico' },
                 { field: 'CPF__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Portal Logístico' }],
                [{ field: 'Usuario_Portal__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Portal Logístico' }, null],
                // Serviços específicos — acompanhamento/etiquetagem
                [{ field: 'RefCliente__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' && (
                       ctx.assunto === 'Realizar acompanhamento (modelo distinto)' ||
                       ctx.assunto === 'Enviar relatório de paletização' ||
                       ctx.assunto === 'Comunicar programação' ||
                       ctx.assunto === 'Informar status de remoção de carga' ||
                       ctx.assunto === 'Gerenciar planilhas de etiquetagem' ||
                       ctx.assunto === 'Gerenciar recebimento de carga' ||
                       ctx.assunto === 'Elaborar romaneio e packing'
                   ) },
                 { field: 'PrestadorServico__c',
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'QSMS' }],
                // Serviços específicos — Atualizar JDA
                [{ field: 'ID_Focus__c', required: true,
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Atualizar JDA com agendamentos' },
                 { field: 'ChavesNF__c',
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Atualizar JDA com agendamentos' }],
                [{ field: 'Janela__c',
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Atualizar JDA com agendamentos' },
                 { field: 'Custo__c',
                   visibleWhen: (ctx) => ctx.tipoCaso === 'Solicitação' && ctx.categoria === 'Serviços específicos' &&
                                        ctx.assunto === 'Lançar serviços e custos adicionais no ECM' }]
            ]
        },
        {
            title: descriptionSectionLabel,
            rows: [[{ field: 'Description', required: true, fullWidth: true }, null]]
        }
    ];
}

// Réplica para "Rebocadores" — extraído de LP_Atendimento_Rebocadores em 2026-06-27. Bem mais
// simples que Salvador/Rio Grande: nenhum dos campos de "Detalhes" tem regra de visibilidade na
// Lightning Page original (todos aparecem juntos, sempre). A seção "Caso Relacionado" da LP tinha
// mais 4 campos (TipoCasoRelacionado__c, AssuntoCasoRelacionado__c, CategoriaCasoRelacionado__c,
// SubassuntoCasoRelacionado__c) que ficam de fora aqui de propósito: são fórmulas que leem do
// Parent (`TEXT(Parent.Assunto__c)` etc.) — só fazem sentido depois que o Case já existe com o
// Caso Pai salvo, igual aos demais campos readonly/fórmula que já ficam fora desta config.
function buildRebocadoresSections() {
    return [
        {
            title: informacoesClienteLabel,
            rows: [
                [{ field: 'AccountId', required: true }, { field: 'ContactId', required: true }],
                [{ field: 'Representante__c' }, null]
            ]
        },
        {
            title: casoRelacionadoLabel,
            rows: [[{ field: 'ParentId' }, null]]
        },
        {
            title: additionalInfoSectionLabel,
            rows: [[{ field: 'Origin', required: true, value: 'Manual' }, { field: 'Priority', value: (ctx) => ctx.prioridade }]]
        },
        {
            title: detalhesLabel,
            rows: [
                [{ field: 'PortoNome__c' }, { field: 'NavioNome__c' }],
                [{ field: 'NumeroNotaFiscal__c' }, { field: 'RepresentanteOuBroker__c' }],
                [{ field: 'PortoCodigoMercante__c' }, { field: 'NavioIMO__c' }],
                [{ field: 'InvoiceCancelada__c' }, null]
            ]
        },
        {
            title: descriptionSectionLabel,
            rows: [[{ field: 'Description', required: true, fullWidth: true }, null]]
        }
    ];
}

const CASE_DETAIL_SECTIONS_BY_UNIDADE = {
    'Atendimento Tecon Salvador': buildSalvadorPatternSections(),
    'Centro Logístico': buildCentroLogisticoSections(),
    'Rebocadores': buildRebocadoresSections(),
    'Atendimento Tecon Rio Grande': buildRioGrandeSections()
};

export default class CaseNewCategorization extends NavigationMixin(LightningElement) {
    @track loading = true;
    @track context;
    @track recordTypeOptions = [];
    @track tipoOptions = [];
    @track categoriaOptions = [];
    @track assuntoOptions = [];
    @track subassuntoOptions = [];
    @track queueOptions = [];
    @track resolvedQueue;
    @track destinationAction = 'ASSUMIR';
    @track destinationManuallySet = false;
    @track selectedQueueDeveloperName;
    @track objectInfo;
    @track customFieldApiName;
    @track customFieldLabel;
    @track customFieldOptions = [];
    @track customFieldValue;
    @track hasParametrizedQueue = false;
    @track permiteAssumir = true;
    @track creating = false;
    @track detailModalidade = null;
    @track detailPrioritySuggested = null;
    @track recordTypeConfirmed = false;

    labels = {
        cardTitle: cardTitleLabel,
        subtitle: subtitleLabel,
        unidadeRecordType: unidadeRecordTypeLabel,
        unidadeNegocio: unidadeNegocioLabel,
        tipoCaso: tipoCasoLabel,
        categoria: categoriaFieldLabel,
        assunto: assuntoLabel,
        subassunto: subassuntoLabel,
        destino: destinoLabel,
        destinationHintAssume: destinationHintAssumeLabel,
        destinationHintDistribute: destinationHintDistributeLabel,
        destinationHintClose: destinationHintCloseLabel,
        queueResolved: queueResolvedLabel,
        manualQueue: manualQueueLabel,
        cancel: cancelLabel,
        loading: loadingLabel,
        saving: savingLabel,
        assume: assumeLabel,
        distribute: distributeLabel,
        close: closeLabel,
        assumirBloqueadoHint: assumirBloqueadoHintLabel,
        errorTitle: errorTitleLabel,
        unexpected: unexpectedLabel,
        prepareFailed: prepareFailedLabel,
        resolveFailed: resolveFailedLabel,
        save: saveLabel,
        continueButton: continueButtonLabel,
        successTitle: successTitleLabel,
        successMsg: successMsgLabel,
        createFailed: createFailedLabel,
        ctxTitle: contextSectionLabel,
        categorizationTitle: categorizacaoLabel,
        destinationTitle: destinationSectionLabel,
        caseDetailsTitle: detalhesLabel
    };

    originalDefaults = {};

    model = {
        recordTypeId: null,
        recordTypeDeveloperName: null,
        unidadeNegocio: null,
        tipoCaso: null,
        categoria: null,
        assunto: null,
        subassunto: null
    };

    @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    wiredObjectInfo({ data }) {
        if (data) this.objectInfo = data;
    }

    @wire(CurrentPageReference)
    parsePageRef(pageRef) {
        const df = pageRef?.state?.defaultFieldValues;
        this.originalDefaults = df ? decodeDefaultFieldValues(df) : {};
    }

    connectedCallback() {
        this.init();
    }

    get destinationOptions() {
        return [
            { label: this.labels.assume, value: 'ASSUMIR' },
            { label: this.labels.distribute, value: 'DISTRIBUIR' },
            { label: this.labels.close, value: 'ENCERRAR' }
        ];
    }

    get assumirBloqueado() {
        return this.hasParametrizedQueue && !this.permiteAssumir;
    }

    get destinationCards() {
        const assumirBloqueado = this.assumirBloqueado;
        return [
            {
                value: 'ASSUMIR',
                label: this.labels.assume,
                description: this.labels.destinationHintAssume,
                checked: this.destinationAction === 'ASSUMIR',
                disabled: assumirBloqueado,
                cssClass: this.cardCssClass(this.destinationAction === 'ASSUMIR', assumirBloqueado),
                radioGlyph: this.destinationAction === 'ASSUMIR' ? '◉' : '◯'
            },
            {
                value: 'DISTRIBUIR',
                label: this.labels.distribute,
                description: this.labels.destinationHintDistribute,
                checked: this.destinationAction === 'DISTRIBUIR',
                disabled: false,
                cssClass: this.cardCssClass(this.destinationAction === 'DISTRIBUIR', false),
                radioGlyph: this.destinationAction === 'DISTRIBUIR' ? '◉' : '◯'
            },
            {
                value: 'ENCERRAR',
                label: this.labels.close,
                description: this.labels.destinationHintClose,
                checked: this.destinationAction === 'ENCERRAR',
                disabled: false,
                cssClass: this.cardCssClass(this.destinationAction === 'ENCERRAR', false),
                radioGlyph: this.destinationAction === 'ENCERRAR' ? '◉' : '◯'
            }
        ];
    }

    cardCssClass(checked, disabled) {
        let cssClass = 'destination-card';
        if (checked) cssClass += ' destination-card_selected';
        if (disabled) cssClass += ' destination-card_disabled';
        return cssClass;
    }

    get showCustomField() {
        return !!this.customFieldApiName;
    }

    async init() {
        this.loading = true;
        try {
            this.context = await getInitialContext();
            this.recordTypeOptions = (this.context?.recordTypes || []).map((r) => ({
                label: `${r.unidadeNegocio || r.label} (${r.label})`,
                value: r.recordTypeId,
                devName: r.developerName,
                unidade: r.unidadeNegocio
            }));

            if (this.recordTypeOptions.length === 1) {
                this.setRecordType(this.recordTypeOptions[0]);
                this.recordTypeConfirmed = true;
            } else if (this.context?.defaultRecordTypeId) {
                // Múltiplos Record Types disponíveis: pré-seleciona o default só visualmente no
                // card — ainda exige o clique em "Seguir" antes de abrir o restante do wizard.
                const d = this.recordTypeOptions.find((o) => o.value === this.context.defaultRecordTypeId);
                if (d) this.setRecordType(d);
            }

            if (this.model.recordTypeId && this.model.unidadeNegocio && this.recordTypeConfirmed) {
                await this.loadTreeOptions();
            }
        } catch (e) {
            this.toast(this.labels.errorTitle, this.reduceError(e), 'error');
        } finally {
            this.loading = false;
        }
    }

    setRecordType(option) {
        this.model = {
            ...this.model,
            recordTypeId: option.value,
            recordTypeDeveloperName: option.devName,
            unidadeNegocio: option.unidade
        };
    }

    async loadTreeOptions() {
        if (!this.model.recordTypeId || !this.model.unidadeNegocio) {
            this.tipoOptions = [];
            this.categoriaOptions = [];
            this.assuntoOptions = [];
            this.subassuntoOptions = [];
            return;
        }
        const res = await getTreeOptions({ request: this.model });
        this.tipoOptions = (res?.tipoCasoOptions || []).map((i) => ({ label: i.label, value: i.value }));
        this.categoriaOptions = (res?.categoriaOptions || []).map((i) => ({ label: i.label, value: i.value }));
        this.assuntoOptions = (res?.assuntoOptions || []).map((i) => ({ label: i.label, value: i.value }));
        this.subassuntoOptions = (res?.subassuntoOptions || []).map((i) => ({ label: i.label, value: i.value }));
    }

    handleRecordTypeChange(event) {
        const selected = this.recordTypeOptions.find((o) => o.value === event.detail.value);
        this.applyRecordTypeSelection(selected);
    }

    handleRecordTypeCardSelect(event) {
        const value = event.currentTarget?.dataset?.value;
        if (!value || value === this.model.recordTypeId) return;
        const selected = this.recordTypeOptions.find((o) => o.value === value);
        this.applyRecordTypeSelection(selected);
    }

    applyRecordTypeSelection(selected) {
        if (!selected) return;
        this.model = {
            ...this.model,
            recordTypeId: selected.value,
            recordTypeDeveloperName: selected.devName,
            unidadeNegocio: selected.unidade,
            tipoCaso: null,
            categoria: null,
            assunto: null,
            subassunto: null
        };
        this.destinationAction = 'ASSUMIR';
        this.destinationManuallySet = false;
        this.resetCustomField();
    }

    get showRecordTypeGate() {
        return this.recordTypeOptions.length > 1 && !this.recordTypeConfirmed;
    }

    get disableConfirmRecordType() {
        return !this.model.recordTypeId;
    }

    async confirmRecordType() {
        if (!this.model.recordTypeId) return;
        this.loading = true;
        try {
            this.recordTypeConfirmed = true;
            await this.loadTreeOptions();
        } finally {
            this.loading = false;
        }
    }

    get recordTypeCards() {
        return this.recordTypeOptions.map((option) => {
            const checked = this.model.recordTypeId === option.value;
            let cssClass = 'destination-card';
            if (checked) cssClass += ' destination-card_selected';
            return {
                value: option.value,
                label: option.unidade || option.label,
                description: option.unidade ? option.label : null,
                checked,
                cssClass,
                radioGlyph: checked ? '◉' : '◯'
            };
        });
    }

    resetCustomField() {
        this.customFieldApiName = null;
        this.customFieldLabel = null;
        this.customFieldOptions = [];
        this.customFieldValue = null;
    }

    handleFieldChange(event) {
        this.handleFieldChangeAsync(event);
    }

    async handleFieldChangeAsync(event) {
        const f = event.target.name;
        const updates = { [f]: event.detail.value };

        if (f === 'tipoCaso') {
            updates.categoria = null;
            updates.assunto = null;
            updates.subassunto = null;
        }
        if (f === 'categoria') {
            updates.assunto = null;
            updates.subassunto = null;
        }
        if (f === 'assunto') {
            updates.subassunto = null;
        }
        this.model = { ...this.model, ...updates };
        await this.loadTreeOptions();
        await this.refreshDestinationSection();
    }

    async handleDestinationChange(event) {
        this.destinationManuallySet = true;
        this.destinationAction = event.detail.value;
        await this.refreshDestinationSection();
    }

    async handleDestinationCardSelect(event) {
        const selected = event.currentTarget?.dataset?.value;
        if (!selected || selected === this.destinationAction) return;
        if (selected === 'ASSUMIR' && this.assumirBloqueado) return;
        this.destinationManuallySet = true;
        this.destinationAction = selected;
        await this.refreshDestinationSection();
    }

    async refreshDestinationSection() {
        this.selectedQueueDeveloperName = null;
        this.queueOptions = [];
        this.resolvedQueue = null;

        // Resolve a categorização sempre que a árvore estiver completa, independente do destino
        // atual — só assim é possível sugerir "Distribuir para fila" automaticamente quando a
        // Categorização já está parametrizada para isso (sem exigir que o usuário lembre de mudar
        // o destino manualmente, que por padrão é "Assumir o caso").
        if (!this.model.tipoCaso || !this.model.categoria || !this.model.assunto) {
            this.resetCustomField();
            this.hasParametrizedQueue = false;
            this.permiteAssumir = true;
            this.detailPrioritySuggested = null;
            return;
        }

        let resolved;
        try {
            resolved = await resolveCategorizationSelection({ request: { ...this.model, customFieldValue: this.customFieldValue } });
        } catch (e) {
            return;
        }

        this.detailPrioritySuggested = resolved?.prioridadeSugerida || null;

        if (resolved?.usaCampoCustomizado) {
            this.customFieldApiName = resolved.campoDistribuicao;
            this.customFieldLabel = resolved.campoDistribuicaoLabel;
            this.customFieldOptions = (resolved.campoDistribuicaoOptions || []).map((o) => ({ label: o.label, value: o.value }));

            if (this.customFieldValue == null) {
                // Pré-preenche com o valor configurado na Categorização e refaz a resolução
                // server-side para já refletir se essa sugestão atende ao critério.
                this.customFieldValue = resolved.valorDistribuicao;
                await this.refreshDestinationSection();
                return;
            }
        } else {
            this.resetCustomField();
        }

        this.hasParametrizedQueue = !!resolved?.hasParametrizedQueue;
        this.permiteAssumir = resolved?.permiteAssumirComFilaParametrizada !== false;

        if (this.hasParametrizedQueue && !this.permiteAssumir) {
            // Categorização não permite assumir diretamente quando há fila parametrizada
            // (fixa, por campo customizado batendo o critério, ou fallback) — trava o destino
            // mesmo que o usuário já tivesse escolhido manualmente outro antes.
            this.destinationAction = 'DISTRIBUIR';
        } else if (this.hasParametrizedQueue && !this.destinationManuallySet) {
            this.destinationAction = 'DISTRIBUIR';
        }

        if (this.destinationAction === 'DISTRIBUIR') {
            this.resolvedQueue = resolved?.queue;
            if (!resolved?.hasParametrizedQueue) {
                const queues = await getAvailableQueues({ recordTypeDeveloperName: this.model.recordTypeDeveloperName, unidadeNegocio: this.model.unidadeNegocio });
                this.queueOptions = (queues || []).map((q) => ({ label: `${q.name} (${q.developerName})`, value: q.developerName }));
            }
        }
    }

    async handleCustomFieldChange(event) {
        this.customFieldValue = event.detail.value;
        await this.refreshDestinationSection();
    }

    handleQueueChange(event) {
        this.selectedQueueDeveloperName = event.detail.value;
    }

    get showQueueSelector() {
        return this.destinationAction === 'DISTRIBUIR' && !this.resolvedQueue;
    }

    get fieldLabels() {
        const fields = this.objectInfo?.fields || {};
        return {
            unidadeNegocio: fields.UnidadeNegocio__c?.label || this.labels.unidadeNegocio,
            tipoCaso: fields.TipoCaso__c?.label || this.labels.tipoCaso,
            categoria: fields.Categoria__c?.label || this.labels.categoria,
            assunto: fields.Assunto__c?.label || this.labels.assunto,
            subassunto: fields.Subassunto__c?.label || this.labels.subassunto
        };
    }

    get disableTipoCaso() {
        return !this.model.recordTypeId || !this.model.unidadeNegocio || this.tipoOptions.length === 0;
    }

    get disableCategoria() {
        return !this.model.tipoCaso || this.categoriaOptions.length === 0;
    }

    get disableAssunto() {
        return !this.model.categoria || this.assuntoOptions.length === 0;
    }

    get disableSubassunto() {
        return !this.model.assunto || this.subassuntoOptions.length === 0;
    }

    findLabel(options, value) {
        const found = (options || []).find((item) => item.value === value);
        return found ? found.label : value;
    }

    get tipoCasoDisplay() {
        return this.findLabel(this.tipoOptions, this.model.tipoCaso);
    }

    get categoriaDisplay() {
        return this.findLabel(this.categoriaOptions, this.model.categoria);
    }

    get assuntoDisplay() {
        return this.findLabel(this.assuntoOptions, this.model.assunto);
    }

    get subassuntoDisplay() {
        return this.findLabel(this.subassuntoOptions, this.model.subassunto);
    }

    get requiredTipoCaso() {
        return this.tipoOptions.length > 0;
    }

    get requiredCategoria() {
        return this.categoriaOptions.length > 0;
    }

    get requiredAssunto() {
        return this.assuntoOptions.length > 0;
    }

    get requiredSubassunto() {
        return this.subassuntoOptions.length > 0;
    }

    cancel() {
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: { objectApiName: 'Case', actionName: 'list' }
        });
    }

    get hasRecordType() {
        return !!(this.model.recordTypeId && this.model.unidadeNegocio);
    }

    get detailContext() {
        return {
            tipoCaso: this.model.tipoCaso,
            categoria: this.model.categoria,
            assunto: this.assuntoDisplay,
            subassunto: this.subassuntoDisplay,
            modalidade: this.detailModalidade,
            prioridade: this.detailPrioritySuggested
        };
    }

    resolveDetailField(fieldConfig, ctx) {
        if (!fieldConfig) return null;
        if (fieldConfig.visibleWhen && !fieldConfig.visibleWhen(ctx)) return null;
        const resolvedValue = typeof fieldConfig.value === 'function' ? fieldConfig.value(ctx) : fieldConfig.value;
        return {
            field: fieldConfig.field,
            required: fieldConfig.required === true,
            value: resolvedValue ?? null,
            fullWidth: fieldConfig.fullWidth === true
        };
    }

    get caseDetailSections() {
        const sections = CASE_DETAIL_SECTIONS_BY_UNIDADE[this.model.unidadeNegocio];
        if (!sections) return null;
        const ctx = this.detailContext;
        return sections
            .filter((section) => !section.visibleWhen || section.visibleWhen(ctx))
            .map((section, sectionIndex) => ({
                key: `case-detail-section-${sectionIndex}`,
                title: section.title,
                rows: section.rows
                    .map((row, rowIndex) => {
                        let left = this.resolveDetailField(row[0], ctx);
                        let right = this.resolveDetailField(row[1], ctx);
                        // Se só o campo da direita estiver visível, empurra para a esquerda —
                        // evita deixar a coluna esquerda vazia com o campo "flutuando" à direita.
                        if (!left && right) {
                            left = right;
                            right = null;
                        }
                        return {
                            key: `case-detail-row-${sectionIndex}-${rowIndex}`,
                            left,
                            right,
                            fullWidth: !!left?.fullWidth
                        };
                    })
                    .filter((row) => row.left || row.right)
            }))
            .filter((section) => section.rows.length > 0);
    }

    get hasCuratedSections() {
        return !!CASE_DETAIL_SECTIONS_BY_UNIDADE[this.model.unidadeNegocio];
    }

    handleDetailFieldChange(event) {
        if (event.target?.fieldName === 'Modalidade__c') {
            this.detailModalidade = event.detail?.value;
        }
    }

    validationError() {
        if (!this.hasRecordType) return this.labels.prepareFailed;
        if (!this.model.tipoCaso || !this.model.categoria) return this.labels.prepareFailed;
        if (this.destinationAction === 'DISTRIBUIR' && !this.resolvedQueue && !this.selectedQueueDeveloperName) {
            return this.labels.prepareFailed;
        }
        return null;
    }

    async handleRecordFormSubmit(event) {
        event.preventDefault();
        const validationMessage = this.validationError();
        if (validationMessage) {
            this.toast(this.labels.errorTitle, validationMessage, 'error');
            return;
        }

        this.creating = true;
        try {
            const req = {
                categorization: { ...this.model, customFieldValue: this.customFieldValue },
                destination: {
                    action: this.destinationAction,
                    selectedQueueDeveloperName: this.selectedQueueDeveloperName
                },
                originalDefaults: this.originalDefaults,
                sourceContext: {}
            };
            const res = await buildDefaultValues({ request: req });
            if (!res?.success) {
                this.toast(this.labels.errorTitle, res?.error?.message || this.labels.resolveFailed, 'error');
                this.creating = false;
                return;
            }

            // Os valores resolvidos pelo wizard (campos do Dynamic Forms, fila, status, etc.) entram
            // como base; qualquer valor que o agente realmente preencheu/alterou no formulário (Conta,
            // Contato, Descrição, e quaisquer campos ainda presentes no Page Layout) prevalece por cima,
            // preservando a mesma semântica de "valor padrão, mas editável" que defaultFieldValues tinha.
            const fields = { ...(res.defaultValues || {}), ...event.detail.fields };
            // Subject (padrão, max 255) não é exibido nessa tela — listas/relatórios legados ainda
            // dependem dele, então espelhamos a Descrição truncada para mantê-lo preenchido.
            if (fields.Description) {
                fields.Subject = fields.Description.substring(0, 255);
            }
            const formEl = this.template.querySelector('lightning-record-edit-form') || this.template.querySelector('lightning-record-form');
            formEl.submit(fields);
        } catch (e) {
            this.creating = false;
            this.toast(this.labels.errorTitle, this.reduceError(e), 'error');
        }
    }

    handleRecordFormSuccess(event) {
        this.creating = false;
        this.toast(this.labels.successTitle, this.labels.successMsg, 'success');
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.detail.id,
                objectApiName: 'Case',
                actionName: 'view'
            }
        });
    }

    handleRecordFormError(event) {
        this.creating = false;
        this.toast(this.labels.errorTitle, this.reduceError(event.detail) || this.labels.createFailed, 'error');
    }

    toast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }

    reduceError(error) {
        if (Array.isArray(error?.body)) return error.body.map((e) => e.message).join(', ');
        return error?.body?.message || error?.message || this.labels.unexpected;
    }
}